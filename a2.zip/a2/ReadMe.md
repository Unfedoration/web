hello vertical here

dropping this since idk why people buy this shit

completely open source go ham with it

if you find someone selling this, pls clown them for me lol

- vertical
https://ogusers.com/vertical